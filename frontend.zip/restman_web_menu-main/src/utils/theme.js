export const PRIMARY_COLOR = 'hsl(348, 100%, 61%)'
export const SECONDARY_COLOR = 'hsl(48, 100%, 67%)'